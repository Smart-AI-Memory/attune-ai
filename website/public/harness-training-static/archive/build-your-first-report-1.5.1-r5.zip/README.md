# Build your first report — local WBT draft

Tutorial 2 of the planned six-part Harness learning path. Unpublished revision
r5, October 29, 2026. The main result is a formatted HTML activity report that
the supplied reporting tool generates from the CSV.

## Open the lesson locally

From this directory, run:

```sh
python3.12 -m http.server 8000 --bind 127.0.0.1
```

Open http://127.0.0.1:8000/index.html. This serves a local preview and does not
publish a website. Choose another port if needed. The lesson has Copy controls,
local reading notes/progress, optional checks, captions and a print view.

## Try the generated report

The opening and closing link to example/expected/activity-report.html. The
checked download is reporting-example.zip; its nine files include the tool,
synthetic data, expected text/HTML, both test files and verification-summary.json.
Extract that ZIP into a fresh folder. Change Terminal’s working directory to
the extracted folder containing report.py and data/activity.csv before running
the command below. Ask your assistant for the exact cd command if needed.
Use an existing Python 3.12 environment:

```sh
python3.12 report.py data/activity.csv --format html --output activity-report.html
```

Open activity-report.html in a browser to read or print it. Existing output files
are preserved; choose a different --output filename to create another report,
then open that same filename. Default text output remains available.

## Current verification and supporting material

The current suite passes all 77 checks: the original 57 text cases are unchanged
and 20 HTML cases were added. A fresh browser download on this Mac reproduced
the delivered HTML and original text exactly and passed all 77 tests on Python
3.12.2. Desktop, 390-pixel mobile and one-page report print views were checked.

Use presenter.md and reporting-lesson-print-r5-folder-step.pdf as supporting snapshots. The
PDF uses links to the local preview. Earlier recordings and 49/57-case evidence
belong to the historical text build/repair; they are not HTML-run evidence.
Native Harness planning/building remains experimental. This local example does
not establish full Windows qualification or learning outcomes. No new native
AI run, newcomer pilot, publication or deployment was performed.
