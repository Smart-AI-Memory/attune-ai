# Presenter script — Build your first report

Local unpublished draft. Derived from site/lesson.json.

## section-1 · See what you can build

Turn six activity entries into a formatted report you can open, explain, and print. Let your AI assistant handle the implementation while you direct the work.

- Start with the useful result: an actual HTML report answers where the work went and can be opened or printed. Point to its dates, total, and project/category breakdown.
- Use the screenshot of the generated report and its actual HTML link. This is the current HTML addition; sections 2–9 retain the earlier text-report build and repair history.
- Do not tell learners they personally built the retained example or present the existing text-report recording as an HTML demonstration.

## section-2 · Start with data you can check

The projects are fictional. The question is practical: where did the work go?

- Give the learner time to check one project total. Coding knowledge is unnecessary.
- The CSV also contains dates. The protected fixture is the source for the six-row example.

## section-3 · Ask for an approach you understand

You do not need to design the parser yourself. Ask the assistant to explain the work and its checks before it starts.

- Have the learner explain the plan in their own words. Avoid a tour of every implementation detail.
- The recorded build used a prepared task. This local lesson does not create a fresh task or run a planner.

## section-4 · Agree to the files and checks

In the historical build, only report.py could change. The checks and their expected answers stayed protected.

- Ask which file contains the expected answer and why the worker should not change it.
- The later test addition was explicitly authorized in a separate repair copy; it did not alter the original protected suite.

## section-5 · Approve the scope before execution

Approval records agreement with the goal, allowed files, and checks. Execution has its own decision.

- Use the two source-verified form labels without presenting a simulated form as an actual Harness screen.
- An incorrect optional answer never prevents moving on. Invite a question rather than scoring the learner.

## section-6 · Give the assistant a bounded go

When the request is ready, explicitly authorize execution for that accepted task and its reviewed limits.

- Explain the difference between reviewing a request and starting its work. Do not run historical checkpoints or native calls during this local tour.
- The recorded configured roles used distinct Codex sessions. The record does not independently attest underlying model identity.

## section-7 · Check the report and the evidence

The historical build produced the expected sample report and passed both protected probes.

- Use the report as the payoff. The learner should connect the total back to the six rows and name one piece of supporting evidence.
- These 49-case results belong to the historical native run, not the later 57-case host repair.

## section-8 · Look at what the reviewer found

Passing the chosen cases is useful evidence. Separate review can still uncover an assumption the tests missed.

- Keep this screen brief. Detailed review judgment belongs to Tutorial 4.
- The screenshot is a crop of the real saved view, not a recreated approval or execution screen.

## section-9 · Make the correction traceable

A later host repair used a separate project copy. The original AI rehearsal and its finding stayed intact.

- Name the new authority: the project owner explicitly approved a repair and regression test in a separate copy. The original task was not rewritten.
- The video runs only the deterministic repaired reporting program, not a new AI build. The recorded tests were not weakened.

## section-10 · Your report, ready to use

The goal is a readable report from the activity CSV. The current tool writes a formatted HTML file you can open in your browser and print.

- Return to the current goal: a formatted HTML report from the CSV. Open the generated report and let the learner check one project total against the rows. Do not imply the learner authored the retained code.
- Invite the learner to download the checked example, have their assistant run its deterministic HTML command, and open the resulting file. The output path must be unused; do not overwrite a prior report.
- The optional VHS recording documents earlier text output. Historical 49-case probes and the later 57-case repair came before HTML support; the current suite adds 20 HTML cases and passes all 77 checks.
- The next-request exercise and Tutorial 3 invitation remain optional. Preserve the stored answer and keep version, platform, and unrun-pilot limits available in the final disclosure.

