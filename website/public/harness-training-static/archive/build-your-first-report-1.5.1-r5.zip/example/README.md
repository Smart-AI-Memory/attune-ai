# Generate a formatted activity report

Turn the supplied synthetic CSV into a standalone HTML report you can open in a
browser and print. This is a local training reference with the current formatted
reporting tool and the earlier text output.

## Generate and open the HTML report

1. Extract the checked example ZIP.
2. Find the extracted folder containing `report.py` and `data/activity.csv`.
3. Ask your assistant for the exact `cd` command to enter that folder. Then run
   the command below using an existing Python 3.12 environment.

On Mac, you can also type `cd` followed by a space in Terminal, drag the extracted folder from
Finder into the window, and press **Return**. Run the following command from
that example folder.

```sh
python3.12 report.py data/activity.csv --format html --output activity-report.html
```

4. Ask your assistant to open `activity-report.html` in your browser, or open the
   file yourself.
5. Check the dates and totals against `data/activity.csv`. Use your browser's print
   command for a paper or PDF copy.

The command creates the output file in the current folder. It refuses to replace
an existing file. To generate another report, choose an unused filename with
`--output`, then open that same filename.

The supplied HTML example is `expected/activity-report.html`. It includes the
report title, date range, entry count, total time, project and category tables,
comparison bars, and a print layout.

## Check the sample result

The six activity entries cover 19–21 October 2026 and total **270 minutes**, or
**4 hours 30 minutes**.

| Project | Minutes |
| --- | ---: |
| Lumen | 90 |
| Orion | 180 |

| Category | Minutes |
| --- | ---: |
| Development | 150 |
| Documentation | 75 |
| Testing | 45 |

The tables show the same time grouped in two ways. Adding either group of totals
returns 270 minutes.

## Optional: print the text report

The default output remains plain text:

```sh
python3.12 report.py data/activity.csv
```

Compare that result with `expected/activity-report.txt`. The retained VHS video
shows this earlier text-report command, not the later HTML format.

## Optional: run the supplied checks

Use an existing Python 3.12 environment that already has pytest:

```sh
python3.12 -m pytest -q -p no:cacheprovider
```

The existing text-report checks remain intact. The current suite passed all 77
checks: the unchanged 57 text cases and 20 new HTML cases. See
[Verification results](verification-summary.json) for the source-bound summary.

## Evidence and limits

The historical native text-report build passed the same 49 cases twice and
retained the medium R1 finding. A later host repair preserved those cases, added
eight regression cases, and passed all 57. Those results came before HTML support
was added; they do not describe the current HTML check count. The original records
remain intact, and the host repair did not run another native AI build.

The retained Harness workflow used version 1.5.1 on macOS. Native planning and
building remain experimental. This example does not establish Windows
qualification or learning outcomes; no newcomer pilot has run.

Use synthetic data. Running this local reporting program needs no model call.
These files authorize no new model work, deployment, or publication.
